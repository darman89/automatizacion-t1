/**
 */
package talleruno;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Usuario Contrase�a</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link talleruno.UsuarioContrase�a#getUsuario <em>Usuario</em>}</li>
 *   <li>{@link talleruno.UsuarioContrase�a#getContrase�a <em>Contrase�a</em>}</li>
 * </ul>
 *
 * @see talleruno.TallerunoPackage#getUsuarioContrase�a()
 * @model
 * @generated
 */
public interface UsuarioContrase�a extends Par�metroConexi�n {
	/**
	 * Returns the value of the '<em><b>Usuario</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Usuario</em>' attribute.
	 * @see #setUsuario(String)
	 * @see talleruno.TallerunoPackage#getUsuarioContrase�a_Usuario()
	 * @model
	 * @generated
	 */
	String getUsuario();

	/**
	 * Sets the value of the '{@link talleruno.UsuarioContrase�a#getUsuario <em>Usuario</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Usuario</em>' attribute.
	 * @see #getUsuario()
	 * @generated
	 */
	void setUsuario(String value);

	/**
	 * Returns the value of the '<em><b>Contrase�a</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contrase�a</em>' attribute.
	 * @see #setContrase�a(String)
	 * @see talleruno.TallerunoPackage#getUsuarioContrase�a_Contrase�a()
	 * @model
	 * @generated
	 */
	String getContrase�a();

	/**
	 * Sets the value of the '{@link talleruno.UsuarioContrase�a#getContrase�a <em>Contrase�a</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Contrase�a</em>' attribute.
	 * @see #getContrase�a()
	 * @generated
	 */
	void setContrase�a(String value);

} // UsuarioContrase�a
