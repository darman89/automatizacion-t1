/**
 */
package talleruno;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Servidor Base Datos</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see talleruno.TallerunoPackage#getServidorBaseDatos()
 * @model abstract="true"
 * @generated
 */
public interface ServidorBaseDatos extends Recurso {
} // ServidorBaseDatos
