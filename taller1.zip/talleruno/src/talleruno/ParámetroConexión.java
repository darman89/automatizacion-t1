/**
 */
package talleruno;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Par�metro Conexi�n</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see talleruno.TallerunoPackage#getPar�metroConexi�n()
 * @model abstract="true"
 * @generated
 */
public interface Par�metroConexi�n extends EObject {
} // Par�metroConexi�n
