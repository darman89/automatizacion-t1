/**
 */
package talleruno;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Llave</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link talleruno.Llave#getSecreto <em>Secreto</em>}</li>
 * </ul>
 *
 * @see talleruno.TallerunoPackage#getLlave()
 * @model
 * @generated
 */
public interface Llave extends Par�metroConexi�n {
	/**
	 * Returns the value of the '<em><b>Secreto</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Secreto</em>' attribute.
	 * @see #setSecreto(String)
	 * @see talleruno.TallerunoPackage#getLlave_Secreto()
	 * @model
	 * @generated
	 */
	String getSecreto();

	/**
	 * Sets the value of the '{@link talleruno.Llave#getSecreto <em>Secreto</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Secreto</em>' attribute.
	 * @see #getSecreto()
	 * @generated
	 */
	void setSecreto(String value);

} // Llave
