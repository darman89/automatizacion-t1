/**
 */
package talleruno.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

import talleruno.Par�metroConexi�n;
import talleruno.TallerunoPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Par�metro Conexi�n</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class Par�metroConexi�nImpl extends MinimalEObjectImpl.Container implements Par�metroConexi�n {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected Par�metroConexi�nImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TallerunoPackage.Literals.PAR�METRO_CONEXI�N;
	}

} //Par�metroConexi�nImpl
