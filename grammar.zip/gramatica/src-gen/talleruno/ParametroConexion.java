/**
 */
package talleruno;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Parametro Conexion</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see talleruno.GramaticaPackage#getParametroConexion()
 * @model abstract="true"
 * @generated
 */
public interface ParametroConexion extends EObject {
} // ParametroConexion
