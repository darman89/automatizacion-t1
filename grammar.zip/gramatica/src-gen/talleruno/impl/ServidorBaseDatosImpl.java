/**
 */
package talleruno.impl;

import org.eclipse.emf.ecore.EClass;

import talleruno.GramaticaPackage;
import talleruno.ServidorBaseDatos;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Servidor Base Datos</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class ServidorBaseDatosImpl extends RecursoImpl implements ServidorBaseDatos {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected ServidorBaseDatosImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return GramaticaPackage.Literals.SERVIDOR_BASE_DATOS;
	}

} //ServidorBaseDatosImpl
